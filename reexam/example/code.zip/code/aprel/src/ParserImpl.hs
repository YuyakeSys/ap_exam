-- Put your parser implementation in this file
module ParserImpl where

import qualified Data.Set as S
import AST
-- import ReadP or Parsec, as relevant

-- Do not change the type!
parseRE :: String -> Either String RE
parseRE = undefined
