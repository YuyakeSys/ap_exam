-module(test_shinobi).

% You are allowed to split your test code in as many files as you
% think is appropriate, just remember that they should all start with
% 'test_'.
% But you MUST have a module (this file) called test_shinobi.

-export([test_all/0, test_everything/0]).
-export([]). % You may have other exports as well

test_all() ->
  not_implemented.

test_everything() ->
  not_implemented.
