-- This is a sample white-box skeleton. No constraints on what you do here.

import AST
import ParserImpl
import MatcherImpl

main :: IO ()
main = putStrLn "White-box tests succeeded!"
