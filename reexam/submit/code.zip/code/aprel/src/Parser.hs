-- Do not modify this file. Put all your code in ParserImpl.hs
module Parser (parseRE) where

import ParserImpl
